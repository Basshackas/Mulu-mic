# Tercha WiFi Mic — Mission 2 hotfix

Android-to-Android Wi-Fi Direct audio prototype.

## Fix in this package
- Avoids calling `AudioTrack.setPreferredDevice(null)` when System default is selected. Some Android audio implementations reject the null/default device with `port out of range: -1`.
- Explicit output routing is attempted only for a currently enumerated output device; if it is unavailable, Android's normal system routing is retained.
- Keeps the existing Wi-Fi Direct and PCM audio prototype.

## Build
Open `android/` in Android Studio or use the repository's GitHub Actions workflow. This source package has not been tested on the user's physical devices. It is a development prototype, not a production-ready audio app.
