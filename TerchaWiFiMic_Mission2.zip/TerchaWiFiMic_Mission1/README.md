# Tercha WiFi Mic — Mission 2 (0.5.0)

**Purpose:** live microphone audio from Phone A to Phone B over Wi-Fi Direct, with a receiver-side audio output selector.

## Two-phone setup
1. Build and install this same Android app on both phones (this ZIP is source code, not an APK).
2. Enable Wi-Fi on both phones and grant the requested Nearby Wi-Fi Devices / Location and microphone permissions.
3. On Phone B, choose **Receiver — create Wi-Fi Direct group**.
4. On Phone A, choose **Microphone — discover receiver**, then tap Phone B in the list.
5. After the connection is established, tap **Start microphone** on Phone A.
6. On Phone B, use **Receiver audio output** to choose System default, phone speaker, Bluetooth, wired headset, or USB audio when Android reports that device. Tap **Refresh audio outputs** after connecting or disconnecting an audio device.

## Audio implementation
- 48 kHz, mono, signed 16-bit PCM.
- 480 samples per packet (10 ms), plus a 4-byte sequence number.
- UDP over the Wi-Fi Direct group; Phone A sends to the group-owner address reported by Android.
- Phone B plays received audio using `AudioTrack` and can request a preferred Android output device.

## Important limitations
- This is an early prototype, not a production-ready microphone system.
- The source has **not been compiled or tested on physical phones** in this environment. Android Studio with the Android SDK is required to build an APK.
- Android manufacturers vary in Wi-Fi Direct discovery, permissions, and audio routing. The output selector only lists devices Android reports; selecting a device is a routing request and may not be honored by every phone or Bluetooth accessory.
- No adaptive jitter buffer, Opus compression, encryption, foreground service, automatic reconnect, or latency calibration yet.
- Bluetooth audio to the RDS mixer can add noticeable delay. A compatible wired USB-C audio adapter/line connection is usually better for low latency.
- Keep the microphone phone away from loud speakers and begin with mixer/speaker volume low to avoid acoustic feedback.

## Next testing step
Test first with two Android phones on the same table, using headphones or low speaker volume. Record each phone model, Android version, whether discovery succeeds, whether audio is heard, and which output route is selected. Do not use this prototype for important live events until it has been tested reliably.
