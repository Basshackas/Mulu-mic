plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.tercha.wifimic"; compileSdk = 35; defaultConfig { applicationId = "com.tercha.wifimic"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "0.5.0" } }

