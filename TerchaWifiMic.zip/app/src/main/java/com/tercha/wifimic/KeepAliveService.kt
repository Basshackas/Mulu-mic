package com.tercha.wifimic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

// Keeps the app alive (screen off / app in background) while a session is running.
// It holds a CPU wake lock and a Wi-Fi lock. The audio engine itself stays in MainActivity.
class KeepAliveService : Service() {

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val role = intent?.getStringExtra("role") ?: "rx"
        val text = if (role == "mic") "Microphone is active" else "Receiver is active"
        val channelId = "tercha_live"

        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Live audio", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else Notification.Builder(this)
        val notification = builder
            .setContentTitle("Tercha WiFi Mic")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val type = if (role == "mic") ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                           else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                startForeground(1, notification, type)
            } else {
                startForeground(1, notification)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (wake == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tercha:live")
            w.setReferenceCounted(false)
            w.acquire(8 * 60 * 60 * 1000L)
            wake = w
        }
        if (wifi == null) {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                       else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val l = wm.createWifiLock(mode, "tercha:wifi")
            l.setReferenceCounted(false)
            l.acquire()
            wifi = l
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        try { wifi?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        wake = null
        wifi = null
        super.onDestroy()
    }
}
