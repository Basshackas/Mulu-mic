package com.tercha.wifimic

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.audiofx.NoiseSuppressor
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.Random
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : Activity() {

    companion object {
        const val PORT = 5005
        const val DISC_PORT = 5006
        const val HELLO = "TWM-HELLO:"
        const val ACK = "TWM-ACK:"
        const val SET = "TWM-SET:"
        const val DENY = "TWM-DENY"
        const val DISCOVER = "TWM-DISCOVER"
        const val HERE = "TWM-HERE:"

        // Audio format: 16 kHz, 16-bit, mono, 20 ms per packet
        const val RATE = 16000
        const val FRAME_SAMPLES = 320
        const val FRAME_BYTES = 640
        const val HEADER = 10             // tag(1) + streamId(4) + seq(4) + micLevel(1)
        const val AUDIO_TAG: Byte = 0x41  // 'A'
        const val BEEP_TOTAL = 6          // 6 x 20 ms test beep
    }

    private val ui = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private var onHome = true
    private var sessionCounter = 0
    private var micCounter = 0
    private var ticker: Runnable? = null

    @Volatile private var activeSession = 0
    @Volatile private var socket: DatagramSocket? = null
    @Volatile private var discSocket: DatagramSocket? = null

    // ----- Saved settings -----
    @Volatile private var soundsOn = true
    @Volatile private var outDeviceId = -1   // -1 = automatic
    private var savedIp = ""
    private var micCode = ""
    private var pairCode = "0000"

    // ----- Microphone phone state (settings are controlled from the receiver) -----
    @Volatile private var micToken = 0
    @Volatile private var micTarget: InetAddress? = null
    @Volatile private var micLevel = 0
    @Volatile private var sentPk = 0
    @Volatile private var micNote = "Microphone is off."
    @Volatile private var micGainPct = 100
    @Volatile private var micMuted = false
    @Volatile private var gateLevel = 0
    @Volatile private var appliedVer = 0
    @Volatile private var nsOn = false
    @Volatile private var nsAvail = false
    @Volatile private var micLinkUp = false
    @Volatile private var lastRtt = 0
    @Volatile private var lastAckAt = 0L
    private var micThread: Thread? = null

    // ----- Receiver phone state -----
    private val queue = LinkedBlockingQueue<ByteArray>()
    private var playThread: Thread? = null
    @Volatile private var playLevel = 0
    @Volatile private var recvPk = 0
    @Volatile private var lostPk = 0
    @Volatile private var lateDup = 0
    @Volatile private var overflow = 0
    @Volatile private var underruns = 0
    @Volatile private var playNote = ""
    @Volatile private var masterPct = 100
    @Volatile private var rxMuted = false
    @Volatile private var prefill = 3        // adaptive jitter buffer target, in frames
    @Volatile private var rxLinkUp = false
    private var haveStream = false
    private var curStream = 0
    private var lastSeq = 0

    // Remote control of the microphone phone (set on the receiver)
    @Volatile private var ctlGain = 100
    @Volatile private var ctlGate = 0
    @Volatile private var ctlMute = false
    @Volatile private var ctlNs = false
    @Volatile private var remoteVer = 0
    @Volatile private var lastUserChange = 0L
    @Volatile private var peerAddr: InetAddress? = null
    @Volatile private var peerPort = 0
    // What the microphone phone reports back
    @Volatile private var repKnown = false
    @Volatile private var repGain = 100
    @Volatile private var repGate = 0
    @Volatile private var repMute = false
    @Volatile private var repNs = false
    @Volatile private var repNsAvail = false
    @Volatile private var repLevel = 0
    @Volatile private var repRtt = 0

    // Delay measurement (beep test)
    @Volatile private var beepFrames = 0
    @Volatile private var beepT0 = 0L
    @Volatile private var beepBase = 0
    @Volatile private var measState = 0      // 0 idle, 1 measuring, 2 done, 3 not heard
    @Volatile private var measMs = 0
    @Volatile private var measBuf = 0
    @Volatile private var measReqAt = 0L

    private var pendingAfterPermission: (() -> Unit)? = null

    private val green = Color.parseColor("#4CAF50")
    private val amber = Color.parseColor("#FFB300")
    private val red = Color.parseColor("#F44336")
    private val accent = Color.parseColor("#6A3DB8")
    private val danger = Color.parseColor("#B71C1C")
    private val cardColor = Color.parseColor("#1A222B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        nsAvail = try { NoiseSuppressor.isAvailable() } catch (e: Exception) { false }
        loadPrefs()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        showHome()
    }

    override fun onPause() {
        savePrefs()
        super.onPause()
    }

    override fun onDestroy() {
        stopTicker()
        stopAll()
        net.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (onHome) super.onBackPressed() else showHome()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1) return
        val action = pendingAfterPermission
        pendingAfterPermission = null
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            micNote = "Microphone permission was denied. Allow it in Settings > Apps > Tercha WiFi Mic > Permissions."
        }
    }

    private fun withMicPermission(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingAfterPermission = action
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    // ---------- Saved settings ----------

    private fun loadPrefs() {
        val p = getSharedPreferences("tercha", MODE_PRIVATE)
        masterPct = p.getInt("master", 100)
        soundsOn = p.getBoolean("sounds", true)
        micGainPct = p.getInt("gain", 100)
        gateLevel = p.getInt("gate", 0)
        nsOn = p.getBoolean("ns", false)
        savedIp = p.getString("ip", "") ?: ""
        micCode = p.getString("micCode", "") ?: ""
        pairCode = p.getString("pairCode", null)
            ?: (1000 + Random().nextInt(9000)).toString().also {
                p.edit().putString("pairCode", it).apply()
            }
    }

    private fun savePrefs() {
        getSharedPreferences("tercha", MODE_PRIVATE).edit()
            .putInt("master", masterPct)
            .putBoolean("sounds", soundsOn)
            .putInt("gain", micGainPct)
            .putInt("gate", gateLevel)
            .putBoolean("ns", nsOn)
            .putString("ip", savedIp)
            .putString("micCode", micCode)
            .apply()
    }

    // ---------- Background service ----------

    private fun startKeepAlive(role: String) {
        try {
            val i = Intent(this, KeepAliveService::class.java).putExtra("role", role)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
        }
    }

    private fun stopKeepAlive() {
        try { stopService(Intent(this, KeepAliveService::class.java)) } catch (e: Exception) { }
    }

    // ---------- Connection sounds (played locally, never sent) ----------

    private fun cue(sid: Int, up: Boolean) {
        ui.post { if (sid == activeSession) playCue(up) }
    }

    private fun playCue(up: Boolean) {
        if (!soundsOn) return
        if (micToken != 0) return   // never while the microphone is capturing
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(if (up) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 300)
            ui.postDelayed({ try { tg.release() } catch (e: Exception) { } }, 800)
        } catch (e: Exception) {
        }
    }

    // ---------- Audio output routes ----------

    private fun outputs(): List<AudioDeviceInfo> {
        val allowed = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_ACCESSORY, AudioDeviceInfo.TYPE_LINE_ANALOG)
        return try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in allowed }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun routeName(d: AudioDeviceInfo): String {
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Phone speaker"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired (3.5 mm)"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB audio"
            AudioDeviceInfo.TYPE_LINE_ANALOG -> "Line out"
            else -> "Other"
        }
        val n = d.productName?.toString() ?: ""
        return if (n.isBlank()) kind else "$kind ($n)"
    }

    private fun outLabel(): String {
        if (outDeviceId == -1) return "Automatic"
        val d = outputs().firstOrNull { it.id == outDeviceId }
        if (d == null) {
            outDeviceId = -1
            return "Automatic"
        }
        return routeName(d)
    }

    private fun chooseOutput() {
        val list = outputs()
        val names = ArrayList<String>()
        names.add("Automatic (system chooses; wired/USB first)")
        for (d in list) names.add(routeName(d))
        AlertDialog.Builder(this)
            .setTitle("Audio output")
            .setItems(names.toTypedArray()) { _, which ->
                val id = if (which == 0) -1 else list[which - 1].id
                outDeviceId = id
            }
            .show()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(40), dp(16), dp(24))
    }

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(10), dp(16), dp(16))
        background = GradientDrawable().apply {
            setColor(cardColor)
            cornerRadius = dp(16).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        addView(label(title, 15f, true, Color.parseColor("#B39DFF")))
    }

    private fun label(t: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(t: String, color: Int = accent) = Button(this).apply {
        text = t
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(12).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    private fun levelBar() = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progress = 0
    }

    // onChange is called only when the PERSON moves the slider, not when the app moves it.
    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max
        this.progress = progress
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { }
            override fun onStopTrackingTouch(sb: SeekBar?) { }
        })
    }

    private fun gateText(v: Int) = if (v == 0) "Noise gate: off" else "Noise gate: $v"

    private fun show(content: View) {
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#0F1419"))
            addView(content)
        })
    }

    private fun startTicker(block: () -> Unit) {
        stopTicker()
        val r = object : Runnable {
            override fun run() {
                block()
                ui.postDelayed(this, 100)
            }
        }
        ticker = r
        ui.post(r)
    }

    private fun stopTicker() {
        ticker?.let { ui.removeCallbacks(it) }
        ticker = null
    }

    // ---------- Screens ----------

    private fun showHome() {
        stopTicker()
        stopAll()
        onHome = true
        val root = column().apply { gravity = Gravity.CENTER_HORIZONTAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(28).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(160), dp(160)).apply {
                bottomMargin = dp(16)
            }
        }
        root.addView(logo)
        root.addView(label("Tercha WiFi Mic", 28f, true))
        root.addView(label("Choose this phone's role", 16f, color = Color.LTGRAY))
        val mic = button("MICROPHONE")
        val rec = button("RECEIVER")
        mic.setOnClickListener { showMic() }
        rec.setOnClickListener { showReceiver() }
        root.addView(mic)
        root.addView(rec)
        show(root)
    }

    private fun showReceiver() {
        stopTicker()
        stopAll()
        onHome = false
        val root = column()
        root.addView(label("RECEIVER", 22f, true))

        // --- Connection card ---
        val c1 = card("Connection")
        c1.addView(label(
            "1. Turn on this phone's Hotspot.\n" +
            "2. Tap Start receiver.\n" +
            "3. On the microphone phone: join this hotspot and enter the pairing code.",
            13f, color = Color.LTGRAY))
        c1.addView(label("Pairing code: $pairCode", 24f, true))
        val status = label("Stopped", 18f, true, amber)
        val qLabel = label("", 14f, true)
        val ips = label(localIps(), 12f, color = Color.LTGRAY)
        val btn = button("Start receiver")
        val hist = java.util.ArrayDeque<IntArray>()
        btn.setOnClickListener {
            if (activeSession != 0) {
                val wasUp = rxLinkUp
                stopAll()
                status.text = "Stopped"
                status.setTextColor(amber)
                btn.text = "Start receiver"
                if (wasUp) playCue(false)
            } else {
                ips.text = localIps()
                hist.clear()
                startReceiver(status)
                startKeepAlive("rx")
                btn.text = "Stop receiver"
            }
        }
        c1.addView(btn)
        c1.addView(status)
        c1.addView(qLabel)
        c1.addView(label("This phone's address(es):", 12f, true))
        c1.addView(ips)

        // --- Output card ---
        val c2 = card("Output")
        val outBtn = button("Output: Automatic")
        outBtn.setOnClickListener { chooseOutput() }
        val routes = label("", 12f, color = Color.LTGRAY)
        val muteOut = button(if (rxMuted) "UNMUTE OUTPUT" else "EMERGENCY MUTE OUTPUT", danger)
        muteOut.setOnClickListener { rxMuted = !rxMuted }
        val bar = levelBar()
        val volLabel = label("Master volume: $masterPct%", 14f, true)
        val vol = seek(100, masterPct) { p ->
            masterPct = p
        }
        val soundBtn = button("Connection sounds: ON")
        soundBtn.setOnClickListener {
            soundsOn = !soundsOn
            savePrefs()
        }
        c2.addView(outBtn)
        c2.addView(routes)
        c2.addView(muteOut)
        c2.addView(label("Received audio level", 13f, true))
        c2.addView(bar)
        c2.addView(volLabel)
        c2.addView(vol)
        c2.addView(soundBtn)

        // --- Remote microphone controls card ---
        val c3 = card("Microphone phone controls")
        val inBar = levelBar()
        val micMuteBtn = button("MUTE MICROPHONE")
        micMuteBtn.setOnClickListener {
            ctlMute = !repMute
            userChanged()
        }
        val gainLabel = label("Microphone gain: $ctlGain%", 14f, true)
        val gain = seek(200, ctlGain) { p ->
            ctlGain = p
            userChanged()
        }
        val gateLabel = label(gateText(ctlGate), 14f, true)
        val gate = seek(60, ctlGate) { p ->
            ctlGate = p
            userChanged()
        }
        val nsBtn = button("NOISE SUPPRESSION")
        nsBtn.setOnClickListener {
            if (!repKnown || repNsAvail) {
                ctlNs = !repNs
                userChanged()
            }
        }
        c3.addView(label("Microphone input (before gate)", 13f, true))
        c3.addView(inBar)
        c3.addView(micMuteBtn)
        c3.addView(gainLabel)
        c3.addView(gain)
        c3.addView(gateLabel)
        c3.addView(gate)
        c3.addView(nsBtn)

        // --- Statistics / latency card ---
        val c4 = card("Statistics and delay")
        val stats = label("", 12f, color = Color.LTGRAY)
        val measBtn = button("Measure delay (plays a beep)")
        measBtn.setOnClickListener { startMeasure() }
        val measText = label("", 12f, color = Color.LTGRAY)
        c4.addView(stats)
        c4.addView(measBtn)
        c4.addView(measText)

        root.addView(c1)
        root.addView(c2)
        root.addView(c3)
        root.addView(c4)
        show(root)

        var lastSnap = 0L
        var outText = "Automatic"
        startTicker {
            val nowT = SystemClock.elapsedRealtime()

            // Once per second: quality history and output list
            if (nowT - lastSnap >= 1000) {
                lastSnap = nowT
                hist.addLast(intArrayOf(recvPk, lostPk, underruns))
                while (hist.size > 6) hist.removeFirst()
                outText = outLabel()
                routes.text = "Detected outputs: " + outputs().joinToString(", ") { routeName(it) }
            }
            var q = "Receiver stopped"
            var qc = Color.GRAY
            if (activeSession != 0) {
                q = "Waiting for signal"
                qc = amber
                if (hist.size >= 2) {
                    val a = hist.peekFirst()
                    val b = hist.peekLast()
                    if (a != null && b != null) {
                        val dRecv = b[0] - a[0]
                        val dLost = b[1] - a[1]
                        val dUnder = b[2] - a[2]
                        if (dRecv > 0) {
                            val lossPct = dLost * 100.0 / (dRecv + dLost)
                            if (lossPct < 1.0 && dUnder == 0) { q = "Good"; qc = green }
                            else if (lossPct < 5.0 && dUnder <= 2) { q = "Fair"; qc = amber }
                            else { q = "Poor"; qc = red }
                        }
                    }
                }
            }
            qLabel.text = "Connection quality: $q"
            qLabel.setTextColor(qc)

            inBar.progress = repLevel
            bar.progress = playLevel
            outBtn.text = "Output: $outText"
            muteOut.text = if (rxMuted) "UNMUTE OUTPUT" else "EMERGENCY MUTE OUTPUT"
            volLabel.text = "Master volume: $masterPct%"
            soundBtn.text = "Connection sounds: " + (if (soundsOn) "ON" else "OFF")

            // Follow the microphone phone's real settings unless the person is adjusting.
            val idle = nowT - lastUserChange > 2000 && !gain.isPressed && !gate.isPressed
            if (repKnown && idle) {
                ctlGain = repGain
                ctlGate = repGate
                ctlMute = repMute
                ctlNs = repNs
            }
            if (gain.progress != ctlGain) gain.progress = ctlGain
            if (gate.progress != ctlGate) gate.progress = ctlGate
            gainLabel.text = "Microphone gain: $ctlGain%"
            gateLabel.text = gateText(ctlGate)
            micMuteBtn.text = if (repKnown && repMute) "UNMUTE MICROPHONE" else "MUTE MICROPHONE"
            nsBtn.text = if (!repKnown) "NOISE SUPPRESSION"
                else if (!repNsAvail) "NOISE SUPPRESSION: not supported on that phone"
                else if (repNs) "NOISE SUPPRESSION: ON"
                else "NOISE SUPPRESSION: OFF"

            val total = recvPk + lostPk
            val pct = if (total > 0) lostPk * 100.0 / total else 0.0
            stats.text = (if (!repKnown) "Microphone phone not connected yet.\n" else "") +
                "Packets received: $recvPk\n" +
                "Lost: $lostPk (${"%.1f".format(pct)}%)\n" +
                "Dropped late/duplicate: $lateDup, overflow: $overflow\n" +
                "Buffer: ${queue.size * 20} ms (target ${prefill * 20} ms), underruns: $underruns\n" +
                "Network round trip: $repRtt ms" +
                (if (playNote.isNotEmpty()) "\n$playNote" else "")

            if (measState == 1 && nowT - measReqAt > 6000) measState = 3
            measText.text = when (measState) {
                1 -> "Measuring… keep the microphone phone near the speaker and stay quiet."
                2 -> "Measured loop delay: $measMs ms (speaker path + room + microphone path).\n" +
                    "Estimated end-to-end delay: ${measMs + measBuf} ms."
                3 -> "Beep not heard. Put the microphone phone near the speaker, unmute the output, " +
                    "raise the volume, stay quiet, and try again."
                else -> "Tip: run the test once with Bluetooth and once with wired output to compare."
            }
        }
    }

    private fun showMic() {
        stopTicker()
        stopAll()
        onHome = false
        val root = column()
        root.addView(label("MICROPHONE", 22f, true))

        // --- Connection card ---
        val c1 = card("Connection")
        c1.addView(label(
            "1. Join the receiver phone's hotspot (Wi-Fi settings).\n" +
            "2. Enter the pairing code shown on the receiver.\n" +
            "3. Tap Connect, then Start microphone.",
            13f, color = Color.LTGRAY))
        val gw = gatewayIp()
        val ip = EditText(this).apply {
            setText(if (gw.isNotEmpty()) gw else savedIp)
            hint = "Receiver address, e.g. 192.168.43.1"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_PHONE
        }
        val codeField = EditText(this).apply {
            setText(micCode)
            hint = "4-digit pairing code"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val status = label("Not connected", 18f, true, amber)
        val link = label("", 13f, true)
        val findBtn = button("Find receiver automatically")
        findBtn.setOnClickListener { findReceiver(ip, status) }
        val btn = button("Connect")
        btn.setOnClickListener {
            if (activeSession != 0) {
                val wasUp = micLinkUp
                stopAll()
                status.text = "Not connected"
                status.setTextColor(amber)
                btn.text = "Connect"
                if (wasUp) playCue(false)
            } else {
                val addr = ip.text.toString().trim()
                val code = codeField.text.toString().trim()
                if (!Regex("""\d{1,3}(\.\d{1,3}){3}""").matches(addr)) {
                    status.text = "Enter the receiver's address as four numbers, like 192.168.43.1"
                } else if (code.length != 4) {
                    status.text = "Enter the 4-digit pairing code shown on the receiver."
                } else {
                    micCode = code
                    savedIp = addr
                    savePrefs()
                    micNote = "Microphone is off."
                    appliedVer = 0
                    lastAckAt = 0L
                    startMic(addr, status)
                    btn.text = "Disconnect"
                }
            }
        }
        c1.addView(ip)
        c1.addView(codeField)
        c1.addView(findBtn)
        c1.addView(btn)
        c1.addView(status)
        c1.addView(link)

        // --- Microphone card ---
        val c2 = card("Microphone")
        val micBtn = button("Start microphone")
        micBtn.setOnClickListener {
            if (micToken != 0) {
                micToken = 0
                micLevel = 0
                micNote = "Microphone stopped."
            } else if (activeSession == 0 || micTarget == null) {
                micNote = "Tap Connect first, then start the microphone."
            } else {
                withMicPermission {
                    startKeepAlive("mic")
                    startCapture(activeSession)
                }
            }
        }
        val muteBtn = button(if (micMuted) "UNMUTE" else "MUTE", danger)
        muteBtn.setOnClickListener { micMuted = !micMuted }
        val bar = levelBar()
        val settings = label("", 12f, color = Color.LTGRAY)
        val info = label("", 12f, color = Color.LTGRAY)
        val soundBtn = button("Connection sounds: ON")
        soundBtn.setOnClickListener {
            soundsOn = !soundsOn
            savePrefs()
        }
        c2.addView(micBtn)
        c2.addView(muteBtn)
        c2.addView(label("Microphone level", 13f, true))
        c2.addView(bar)
        c2.addView(settings)
        c2.addView(info)
        c2.addView(soundBtn)

        root.addView(c1)
        root.addView(c2)
        show(root)
        startTicker {
            bar.progress = micLevel
            micBtn.text = if (micToken != 0) "Stop microphone" else "Start microphone"
            muteBtn.text = if (micMuted) "UNMUTE" else "MUTE"
            soundBtn.text = "Connection sounds: " + (if (soundsOn) "ON" else "OFF")
            settings.text = "Gain: $micGainPct%  |  ${gateText(gateLevel)}\n" +
                "Noise suppression: ${if (nsOn) "on" else "off"}\n(set from the receiver phone)"
            info.text = micNote +
                (if (micToken != 0) "\nPackets sent: $sentPk" else "") +
                (if (micMuted) "\nMUTED: silence is being sent" else "")
            val age = SystemClock.elapsedRealtime() - lastAckAt
            if (activeSession == 0) {
                link.text = ""
            } else if (lastAckAt == 0L || age > 3000) {
                link.text = "Link: no reply from the receiver"
                link.setTextColor(amber)
            } else {
                val qual = if (lastRtt < 40) "Good" else if (lastRtt < 120) "Fair" else "Poor"
                link.text = "Link: $qual (round trip $lastRtt ms)"
                link.setTextColor(if (qual == "Good") green else if (qual == "Fair") amber else red)
            }
        }
    }

    // ---------- Network helpers ----------

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String {
        return try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val g = wm.dhcpInfo?.gateway ?: 0
            if (g == 0) "" else "${g and 0xff}.${g shr 8 and 0xff}.${g shr 16 and 0xff}.${g shr 24 and 0xff}"
        } catch (e: Exception) {
            ""
        }
    }

    private fun localIps(): String {
        val list = mutableListOf<String>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address) list.add("${ni.name}: ${a.hostAddress}")
                }
            }
        } catch (e: Exception) {
        }
        return if (list.isEmpty()) "No network address yet. Turn on the hotspot first."
        else list.joinToString("\n")
    }

    private fun broadcastAddresses(): List<InetAddress> {
        val out = mutableListOf<InetAddress>()
        try { out.add(InetAddress.getByName("255.255.255.255")) } catch (e: Exception) { }
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val b = ia.broadcast
                    if (b != null) out.add(b)
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    // Looks for a receiver on the local network and fills in its address.
    private fun findReceiver(ipField: EditText, status: TextView) {
        status.text = "Searching for a receiver…"
        status.setTextColor(amber)
        Thread {
            var ds: DatagramSocket? = null
            var foundIp: String? = null
            var foundName = ""
            try {
                ds = DatagramSocket()
                ds.broadcast = true
                ds.soTimeout = 400
                val msg = DISCOVER.toByteArray()
                for (a in broadcastAddresses()) {
                    try { ds.send(DatagramPacket(msg, msg.size, a, DISC_PORT)) } catch (e: Exception) { }
                }
                val b = ByteArray(128)
                val end = SystemClock.elapsedRealtime() + 1800
                while (foundIp == null && SystemClock.elapsedRealtime() < end) {
                    try {
                        val p = DatagramPacket(b, b.size)
                        ds.receive(p)
                        val m = String(p.data, 0, p.length)
                        if (m.startsWith(HERE)) {
                            foundIp = p.address.hostAddress
                            foundName = m.removePrefix(HERE)
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { ds?.close() } catch (e: Exception) { }
            }
            val f = foundIp
            val n = foundName
            ui.post {
                if (f != null) {
                    ipField.setText(f)
                    status.text = "Found receiver: $n ($f)"
                    status.setTextColor(green)
                } else {
                    status.text = "No receiver found. Is it started, and are both phones on the same Wi-Fi or hotspot?"
                    status.setTextColor(red)
                }
            }
        }.start()
    }

    private fun stopAll() {
        activeSession = 0
        micToken = 0
        micTarget = null
        micLevel = 0
        playLevel = 0
        repLevel = 0
        micLinkUp = false
        rxLinkUp = false
        beepFrames = 0
        measState = 0
        try { socket?.close() } catch (e: Exception) { }
        socket = null
        try { discSocket?.close() } catch (e: Exception) { }
        discSocket = null
        stopKeepAlive()
    }

    private fun post(sid: Int, view: TextView, text: String, color: Int) {
        ui.post {
            if (sid == activeSession) {
                view.text = text
                view.setTextColor(color)
            }
        }
    }

    private fun levelOf(b: ShortArray): Int {
        var sum = 0.0
        for (v in b) sum += v.toDouble() * v.toDouble()
        val rms = sqrt(sum / b.size)
        if (rms < 1.0) return 0
        val db = 20.0 * log10(rms / 32768.0)
        return (((db + 60.0) / 60.0) * 100.0).toInt().coerceIn(0, 100)
    }

    // ---------- Delay measurement (receiver) ----------

    private fun startMeasure() {
        if (activeSession == 0 || !repKnown) {
            measState = 3
            measReqAt = SystemClock.elapsedRealtime() - 7000
            return
        }
        beepBase = repLevel
        beepT0 = 0L
        measMs = 0
        measReqAt = SystemClock.elapsedRealtime()
        measState = 1
        beepFrames = BEEP_TOTAL
    }

    // ---------- Remote control (receiver side) ----------

    // Called when the person changes a microphone control on the receiver.
    private fun userChanged() {
        lastUserChange = SystemClock.elapsedRealtime()
        remoteVer = if (remoteVer == 0) Random().nextInt(1_000_000) + 1 else remoteVer + 1
        sendSet()
    }

    private fun sendSet() {
        val a = peerAddr ?: return
        val sock = socket ?: return
        val text = SET + remoteVer + "|" + ctlGain + "|" + ctlGate + "|" +
            (if (ctlMute) 1 else 0) + "|" + (if (ctlNs) 1 else 0)
        val data = text.toByteArray()
        val port = peerPort
        net.execute {
            try {
                sock.send(DatagramPacket(data, data.size, a, port))
            } catch (e: Exception) {
            }
        }
    }

    // ---------- Remote control (microphone side) ----------

    private fun applyRemote(ver: Int, gain: Int, gate: Int, mute: String, ns: String = "") {
        if (ver == 0 || ver == appliedVer) return
        appliedVer = ver
        micGainPct = gain.coerceIn(0, 200)
        gateLevel = gate.coerceIn(0, 60)
        micMuted = mute == "1"
        if (ns == "0" || ns == "1") nsOn = ns == "1"
        savePrefs()
    }

    // ---------- Receiver ----------

    private fun startReceiver(status: TextView) {
        val sid = ++sessionCounter
        activeSession = sid
        status.text = "Starting…"
        status.setTextColor(amber)

        // Make sure any previous playback engine has fully finished first.
        try { playThread?.join(400) } catch (e: InterruptedException) { }
        queue.clear()
        recvPk = 0; lostPk = 0; lateDup = 0; overflow = 0; underruns = 0
        playNote = ""
        haveStream = false
        prefill = 3
        remoteVer = 0
        ctlGain = 100; ctlGate = 0; ctlMute = false; ctlNs = false
        repKnown = false; repLevel = 0; repRtt = 0
        peerAddr = null
        measState = 0
        beepFrames = 0

        val pt = Thread { playbackLoop(sid) }
        playThread = pt
        pt.start()

        // Discovery responder: lets a microphone phone find this receiver.
        Thread {
            var ds: DatagramSocket? = null
            try {
                ds = DatagramSocket(null)
                ds.reuseAddress = true
                ds.bind(InetSocketAddress(DISC_PORT))
                ds.soTimeout = 500
                discSocket = ds
                val b = ByteArray(128)
                while (activeSession == sid) {
                    try {
                        val p = DatagramPacket(b, b.size)
                        ds.receive(p)
                        if (String(p.data, 0, p.length).startsWith(DISCOVER)) {
                            val r = (HERE + Build.MODEL).toByteArray()
                            ds.send(DatagramPacket(r, r.size, p.address, p.port))
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { ds?.close() } catch (e: Exception) { }
            }
        }.start()

        Thread {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(PORT))
                s.soTimeout = 500
                socket = s
                post(sid, status, "Waiting for the microphone phone…", amber)
                val buf = ByteArray(2048)
                var connected = false
                var lastSeen = 0L
                while (activeSession == sid) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        if (p.length > 0 && buf[0] == AUDIO_TAG) {
                            val pa = peerAddr
                            if (pa != null && p.address == pa) {
                                handleAudio(p)
                                lastSeen = SystemClock.elapsedRealtime()
                                if (!connected) {
                                    connected = true
                                    rxLinkUp = true
                                    post(sid, status, "Connected to ${p.address.hostAddress}", green)
                                    cue(sid, true)
                                }
                            }
                        } else {
                            val msg = String(p.data, 0, p.length)
                            if (msg.startsWith(HELLO)) {
                                val parts = msg.removePrefix(HELLO).split("|")
                                if (parts.size >= 9) {
                                    if (parts[0] != pairCode) {
                                        val d = DENY.toByteArray()
                                        s.send(DatagramPacket(d, d.size, p.address, p.port))
                                    } else {
                                        repGain = parts[3].toIntOrNull() ?: repGain
                                        repGate = parts[4].toIntOrNull() ?: repGate
                                        repMute = parts[5] == "1"
                                        repNs = parts[6] == "1"
                                        repNsAvail = parts[7] == "1"
                                        repRtt = parts[8].toIntOrNull() ?: repRtt
                                        repKnown = true
                                        peerAddr = p.address
                                        peerPort = p.port
                                        val reply = (ACK + parts[1] + "|" + remoteVer + "|" + ctlGain +
                                            "|" + ctlGate + "|" + (if (ctlMute) 1 else 0) +
                                            "|" + (if (ctlNs) 1 else 0)).toByteArray()
                                        s.send(DatagramPacket(reply, reply.size, p.address, p.port))
                                        lastSeen = SystemClock.elapsedRealtime()
                                        if (!connected) {
                                            connected = true
                                            rxLinkUp = true
                                            post(sid, status, "Connected to ${p.address.hostAddress}", green)
                                            cue(sid, true)
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                    if (connected && SystemClock.elapsedRealtime() - lastSeen > 3000) {
                        connected = false
                        rxLinkUp = false
                        repKnown = false
                        repLevel = 0
                        post(sid, status, "Microphone phone disconnected. Waiting…", amber)
                        cue(sid, false)
                    }
                }
            } catch (e: Exception) {
                if (activeSession == sid) {
                    post(sid, status,
                        "Receiver could not start: ${e.message}. Close the app fully and try again.", red)
                }
            } finally {
                try { s?.close() } catch (e: Exception) { }
            }
        }.start()
    }

    // Runs on the receive thread only.
    private fun handleAudio(p: DatagramPacket) {
        if (p.length != HEADER + FRAME_BYTES) return
        val bb = ByteBuffer.wrap(p.data, 0, p.length).order(ByteOrder.LITTLE_ENDIAN)
        bb.get()
        val stream = bb.int
        val seq = bb.int
        repLevel = bb.get().toInt() and 0xff

        // Delay measurement: look for the test beep coming back through the microphone.
        if (measState == 1 && beepT0 > 0L) {
            val now = SystemClock.elapsedRealtime()
            if (now > beepT0 && repLevel >= maxOf(35, beepBase + 25)) {
                measMs = (now - beepT0).toInt()
                measBuf = queue.size * 20
                measState = 2
            }
        }

        if (!haveStream || stream != curStream) {
            haveStream = true
            curStream = stream
            lastSeq = seq - 1
            queue.clear()
        }
        val d = seq - lastSeq
        if (d <= 0) {
            // Duplicate or late packet: never play it twice.
            lateDup++
            return
        }
        if (d > 1) lostPk += d - 1
        lastSeq = seq
        recvPk++
        val payload = ByteArray(FRAME_BYTES)
        System.arraycopy(p.data, HEADER, payload, 0, FRAME_BYTES)
        queue.offer(payload)
        while (queue.size > prefill + 5) {
            queue.poll()
            overflow++
        }
    }

    // The ONE playback engine. Exactly one of these runs per receiver session.
    private fun playbackLoop(sid: Int) {
        var track: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufSize = maxOf(minBuf, FRAME_BYTES * 4)
            val builder = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(bufSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (Build.VERSION.SDK_INT >= 26) {
                builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            }
            track = builder.build()
            track.play()

            val silence = ShortArray(FRAME_SAMPLES)
            val pcm = ShortArray(FRAME_SAMPLES)
            var playing = false
            var appliedOut = -2
            var beepPhase = 0.0
            var calmSince = SystemClock.elapsedRealtime()
            while (activeSession == sid) {
                // Apply the chosen output device (speaker, Bluetooth, wired, USB).
                val wantOut = outDeviceId
                if (wantOut != appliedOut) {
                    appliedOut = wantOut
                    try {
                        val dev = if (wantOut == -1) null else outputs().firstOrNull { it.id == wantOut }
                        track.setPreferredDevice(dev)
                    } catch (e: Exception) {
                    }
                }

                var frame: ByteArray? = null
                if (playing) {
                    frame = queue.poll(40, TimeUnit.MILLISECONDS)
                    if (frame == null) {
                        playing = false
                        underruns++
                        // Adaptive buffer: after an underrun, wait for a bit more audio next time.
                        if (prefill < 10) prefill++
                        calmSince = SystemClock.elapsedRealtime()
                    }
                } else if (queue.size >= prefill) {
                    playing = true
                }
                // Adaptive buffer: after 30 calm seconds, shrink the delay again.
                val nowT = SystemClock.elapsedRealtime()
                if (prefill > 3 && nowT - calmSince > 30000) {
                    prefill--
                    calmSince = nowT
                }

                val vol = if (rxMuted) 0f else masterPct / 100f
                val n: Int
                if (beepFrames > 0) {
                    // Delay test beep (1 kHz). Incoming voice is skipped for these 120 ms.
                    if (beepFrames == BEEP_TOTAL) beepT0 = SystemClock.elapsedRealtime()
                    for (i in 0 until FRAME_SAMPLES) {
                        pcm[i] = (sin(beepPhase) * 12000.0 * vol).toInt().toShort()
                        beepPhase += 2.0 * PI * 1000.0 / RATE
                        if (beepPhase > 2.0 * PI) beepPhase -= 2.0 * PI
                    }
                    beepFrames--
                    playLevel = levelOf(pcm)
                    n = track.write(pcm, 0, FRAME_SAMPLES)
                } else if (frame != null) {
                    ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN)
                        .asShortBuffer().get(pcm)
                    playLevel = levelOf(pcm)
                    if (vol < 1.0f) {
                        for (i in 0 until FRAME_SAMPLES) pcm[i] = (pcm[i] * vol).toInt().toShort()
                    }
                    n = track.write(pcm, 0, FRAME_SAMPLES)
                } else {
                    // Nothing to play: output silence. Old audio is never replayed.
                    playLevel = 0
                    n = track.write(silence, 0, FRAME_SAMPLES)
                }
                if (n < 0) throw IOException("Audio output error ($n)")
            }
        } catch (e: Exception) {
            if (activeSession == sid) {
                playNote = "Audio playback problem: ${e.message}"
            }
        } finally {
            playLevel = 0
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
        }
    }

    // ---------- Microphone ----------

    private fun startMic(ip: String, status: TextView) {
        val sid = ++sessionCounter
        activeSession = sid
        status.text = "Connecting to $ip…"
        status.setTextColor(amber)
        Thread {
            var s: DatagramSocket? = null
            try {
                val target = InetAddress.getByName(ip)
                s = DatagramSocket()
                s.soTimeout = 300
                socket = s
                micTarget = target
                val buf = ByteArray(256)
                val startT = SystemClock.elapsedRealtime()
                var lastAck = 0L
                var lastSend = 0L
                var state = 0 // 0 connecting, 1 connected, 2 lost/no reply, 3 wrong code
                while (activeSession == sid) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSend >= 1000) {
                        lastSend = now
                        try {
                            val data = (HELLO + micCode + "|" + System.nanoTime() + "|" + appliedVer +
                                "|" + micGainPct + "|" + gateLevel + "|" + (if (micMuted) 1 else 0) +
                                "|" + (if (nsOn) 1 else 0) + "|" + (if (nsAvail) 1 else 0) +
                                "|" + lastRtt).toByteArray()
                            s.send(DatagramPacket(data, data.size, target, PORT))
                        } catch (e: IOException) {
                            if (activeSession == sid) {
                                post(sid, status,
                                    "Cannot reach the network. Is this phone joined to the receiver's hotspot?", red)
                            }
                        }
                    }
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        if (p.address == target) {
                            val msg = String(p.data, 0, p.length)
                            if (msg.startsWith(ACK)) {
                                val parts = msg.removePrefix(ACK).split("|")
                                val sent = parts[0].toLongOrNull()
                                if (sent != null) {
                                    if (parts.size >= 5) {
                                        applyRemote(parts[1].toIntOrNull() ?: 0,
                                            parts[2].toIntOrNull() ?: 100,
                                            parts[3].toIntOrNull() ?: 0, parts[4],
                                            if (parts.size >= 6) parts[5] else "")
                                    }
                                    val rtt = (System.nanoTime() - sent) / 1_000_000.0
                                    lastRtt = rtt.toInt()
                                    lastAck = SystemClock.elapsedRealtime()
                                    lastAckAt = lastAck
                                    if (state != 1) {
                                        micLinkUp = true
                                        cue(sid, true)
                                    }
                                    state = 1
                                    post(sid, status,
                                        "Connected to $ip\nRound trip: ${"%.1f".format(rtt)} ms", green)
                                }
                            } else if (msg.startsWith(SET)) {
                                val parts = msg.removePrefix(SET).split("|")
                                if (parts.size >= 4) {
                                    applyRemote(parts[0].toIntOrNull() ?: 0,
                                        parts[1].toIntOrNull() ?: 100,
                                        parts[2].toIntOrNull() ?: 0, parts[3],
                                        if (parts.size >= 5) parts[4] else "")
                                }
                            } else if (msg.startsWith(DENY)) {
                                state = 3
                                post(sid, status,
                                    "Wrong pairing code. Type the 4-digit code shown on the receiver.", red)
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                    val t = SystemClock.elapsedRealtime()
                    if (state == 1 && t - lastAck > 3000) {
                        state = 2
                        micLinkUp = false
                        post(sid, status, "Connection lost. Reconnecting automatically…", amber)
                        cue(sid, false)
                    } else if (state == 0 && t - startT > 4000) {
                        state = 2
                        post(sid, status,
                            "No reply from $ip. Check: receiver is started, this phone is on its hotspot, address is correct.", red)
                    }
                }
            } catch (e: Exception) {
                if (activeSession == sid) {
                    post(sid, status, "Could not connect: ${e.message}", red)
                }
            } finally {
                try { s?.close() } catch (e: Exception) { }
            }
        }.start()
    }

    // Starts microphone capture and sends each 20 ms frame as one packet.
    private fun startCapture(sid: Int) {
        val target = micTarget ?: return
        val token = ++micCounter
        micToken = token
        micNote = "Starting microphone…"
        sentPk = 0
        try { micThread?.join(400) } catch (e: InterruptedException) { }
        val t = Thread {
            var rec: AudioRecord? = null
            var ns: NoiseSuppressor? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(
                    RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuf <= 0) throw IOException("This phone does not support the audio format")
                rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, FRAME_BYTES * 4))
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    throw IOException("Microphone could not be opened. Is another app using it?")
                }
                ns = try {
                    if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId) else null
                } catch (e: Exception) { null }
                var nsApplied = -1
                rec.startRecording()
                micNote = "Transmitting"
                val streamId = Random().nextInt()
                var seq = 0
                var gateHold = 0
                var hpX = 0f
                var hpY = 0f
                val shorts = ShortArray(FRAME_SAMPLES)
                while (activeSession == sid && micToken == token) {
                    val wantNs = if (nsOn) 1 else 0
                    if (wantNs != nsApplied) {
                        nsApplied = wantNs
                        try { ns?.setEnabled(nsOn) } catch (e: Exception) { }
                    }
                    var got = 0
                    while (got < FRAME_SAMPLES) {
                        val n = rec.read(shorts, got, FRAME_SAMPLES - got)
                        if (n <= 0) throw IOException("Microphone read failed ($n)")
                        got += n
                        if (micToken != token) break
                    }
                    if (got < FRAME_SAMPLES) break
                    // High-pass filter (about 120 Hz): removes rumble that feeds low-frequency howl.
                    for (i in 0 until FRAME_SAMPLES) {
                        val x = shorts[i].toFloat()
                        val y = 0.955f * (hpY + x - hpX)
                        hpX = x
                        hpY = y
                        shorts[i] = y.toInt().coerceIn(-32768, 32767).toShort()
                    }
                    val gp = micGainPct
                    if (gp != 100) {
                        val g = gp / 100f
                        for (i in 0 until FRAME_SAMPLES) {
                            shorts[i] = (shorts[i] * g).toInt().coerceIn(-32768, 32767).toShort()
                        }
                    }
                    val lvl = levelOf(shorts)
                    micLevel = lvl
                    val gl = gateLevel
                    var silent = micMuted
                    if (gl > 0) {
                        if (lvl >= gl) gateHold = 10
                        else if (gateHold > 0) gateHold--
                        else silent = true
                    }
                    if (silent) java.util.Arrays.fill(shorts, 0.toShort())
                    val bb = ByteBuffer.allocate(HEADER + FRAME_BYTES).order(ByteOrder.LITTLE_ENDIAN)
                    bb.put(AUDIO_TAG)
                    bb.putInt(streamId)
                    bb.putInt(seq)
                    bb.put(lvl.toByte())
                    for (v in shorts) bb.putShort(v)
                    val sock = socket ?: break
                    try {
                        sock.send(DatagramPacket(bb.array(), bb.capacity(), target, PORT))
                        sentPk++
                    } catch (e: IOException) {
                        micNote = "Cannot send audio. Is this phone still on the receiver's hotspot?"
                    }
                    seq++
                }
            } catch (e: Exception) {
                micNote = "Microphone problem: ${e.message}"
            } finally {
                micLevel = 0
                try { ns?.release() } catch (e: Exception) { }
                try { rec?.stop() } catch (e: Exception) { }
                try { rec?.release() } catch (e: Exception) { }
                if (micToken == token) micToken = 0
            }
        }
        micThread = t
        t.start()
    }
}
