package com.tercha.wifimic

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.Random
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.log10
import kotlin.math.sqrt

class MainActivity : Activity() {

    companion object {
        const val PORT = 5005
        const val HELLO = "TWM-HELLO:"
        const val ACK = "TWM-ACK:"

        // Audio format: 16 kHz, 16-bit, mono, 20 ms per packet
        const val RATE = 16000
        const val FRAME_SAMPLES = 320
        const val FRAME_BYTES = 640
        const val HEADER = 9              // tag(1) + streamId(4) + seq(4)
        const val AUDIO_TAG: Byte = 0x41  // 'A'
        const val PREFILL = 3             // frames to collect before playing (60 ms)
        const val MAX_QUEUE = 8           // max frames kept (160 ms); older ones are dropped
    }

    private val ui = Handler(Looper.getMainLooper())
    private var onHome = true
    private var sessionCounter = 0
    private var micCounter = 0
    private var ticker: Runnable? = null

    @Volatile private var activeSession = 0
    @Volatile private var socket: DatagramSocket? = null

    // Microphone side
    @Volatile private var micToken = 0
    @Volatile private var micTarget: InetAddress? = null
    @Volatile private var micLevel = 0
    @Volatile private var sentPk = 0
    @Volatile private var micNote = "Microphone is off."
    private var micThread: Thread? = null

    // Receiver side
    private val queue = LinkedBlockingQueue<ByteArray>()
    private var playThread: Thread? = null
    @Volatile private var playLevel = 0
    @Volatile private var recvPk = 0
    @Volatile private var lostPk = 0
    @Volatile private var lateDup = 0
    @Volatile private var overflow = 0
    @Volatile private var underruns = 0
    @Volatile private var playNote = ""
    private var haveStream = false
    private var curStream = 0
    private var lastSeq = 0

    private var pendingAfterPermission: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showHome()
    }

    override fun onDestroy() {
        stopTicker()
        stopAll()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (onHome) super.onBackPressed() else showHome()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val action = pendingAfterPermission
        pendingAfterPermission = null
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            micNote = "Microphone permission was denied. Allow it in Settings > Apps > Tercha WiFi Mic > Permissions."
        }
    }

    private fun withMicPermission(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingAfterPermission = action
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(48), dp(24), dp(24))
    }

    private fun label(t: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }

    private fun button(t: String) = Button(this).apply { text = t }

    private fun levelBar() = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progress = 0
    }

    private fun show(content: View) {
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#101418"))
            addView(content)
        })
    }

    private fun startTicker(block: () -> Unit) {
        stopTicker()
        val r = object : Runnable {
            override fun run() {
                block()
                ui.postDelayed(this, 100)
            }
        }
        ticker = r
        ui.post(r)
    }

    private fun stopTicker() {
        ticker?.let { ui.removeCallbacks(it) }
        ticker = null
    }

    // ---------- Screens ----------

    private fun showHome() {
        stopTicker()
        stopAll()
        onHome = true
        val root = column().apply { gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(label("Tercha WiFi Mic", 28f, true))
        root.addView(label("Choose this phone's role", 16f, color = Color.LTGRAY))
        val mic = button("MICROPHONE")
        val rec = button("RECEIVER")
        mic.setOnClickListener { showMic() }
        rec.setOnClickListener { showReceiver() }
        root.addView(mic)
        root.addView(rec)
        show(root)
    }

    private fun showReceiver() {
        stopTicker()
        stopAll()
        onHome = false
        val root = column()
        root.addView(label("RECEIVER", 22f, true))
        root.addView(label(
            "1. Turn on this phone's Hotspot (Settings).\n" +
            "2. Tap Start receiver.\n" +
            "3. On the microphone phone, join this hotspot.",
            14f, color = Color.LTGRAY))
        val status = label("Stopped", 18f, true, amber)
        val ips = label(localIps(), 14f, color = Color.LTGRAY)
        val bar = levelBar()
        val stats = label("", 13f, color = Color.LTGRAY)
        val btn = button("Start receiver")
        btn.setOnClickListener {
            if (activeSession != 0) {
                stopAll()
                status.text = "Stopped"
                status.setTextColor(amber)
                btn.text = "Start receiver"
            } else {
                ips.text = localIps()
                startReceiver(status)
                btn.text = "Stop receiver"
            }
        }
        root.addView(btn)
        root.addView(status)
        root.addView(label("Received audio level", 14f, true))
        root.addView(bar)
        root.addView(stats)
        root.addView(label("This phone's address(es):", 14f, true))
        root.addView(ips)
        show(root)
        startTicker {
            bar.progress = playLevel
            val total = recvPk + lostPk
            val pct = if (total > 0) lostPk * 100.0 / total else 0.0
            stats.text = "Packets received: $recvPk\n" +
                "Lost: $lostPk (${"%.1f".format(pct)}%)\n" +
                "Dropped late/duplicate: $lateDup, overflow: $overflow\n" +
                "Buffer: ${queue.size * 20} ms, underruns: $underruns" +
                (if (playNote.isNotEmpty()) "\n$playNote" else "")
        }
    }

    private fun showMic() {
        stopTicker()
        stopAll()
        onHome = false
        val root = column()
        root.addView(label("MICROPHONE", 22f, true))
        root.addView(label(
            "1. Join the receiver phone's hotspot in Wi-Fi settings.\n" +
            "2. Check the receiver's address below.\n" +
            "3. Tap Connect, then Start microphone.\n" +
            "Keep this phone away from the speakers.",
            14f, color = Color.LTGRAY))
        val ip = EditText(this).apply {
            setText(gatewayIp())
            hint = "Receiver address, e.g. 192.168.43.1"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_PHONE
        }
        val status = label("Not connected", 18f, true, amber)
        val btn = button("Connect")
        val micBtn = button("Start microphone")
        val bar = levelBar()
        val info = label("", 13f, color = Color.LTGRAY)
        btn.setOnClickListener {
            if (activeSession != 0) {
                stopAll()
                status.text = "Not connected"
                status.setTextColor(amber)
                btn.text = "Connect"
            } else {
                val addr = ip.text.toString().trim()
                if (!Regex("""\d{1,3}(\.\d{1,3}){3}""").matches(addr)) {
                    status.text = "Enter the receiver's address as four numbers, like 192.168.43.1"
                } else {
                    micNote = "Microphone is off."
                    startMic(addr, status)
                    btn.text = "Disconnect"
                }
            }
        }
        micBtn.setOnClickListener {
            if (micToken != 0) {
                micToken = 0
                micLevel = 0
                micNote = "Microphone stopped."
            } else if (activeSession == 0 || micTarget == null) {
                micNote = "Tap Connect first, then start the microphone."
            } else {
                withMicPermission { startCapture(activeSession) }
            }
        }
        root.addView(ip)
        root.addView(btn)
        root.addView(status)
        root.addView(micBtn)
        root.addView(label("Microphone level", 14f, true))
        root.addView(bar)
        root.addView(info)
        show(root)
        startTicker {
            bar.progress = micLevel
            micBtn.text = if (micToken != 0) "Stop microphone" else "Start microphone"
            info.text = micNote + (if (micToken != 0) "\nPackets sent: $sentPk" else "")
        }
    }

    // ---------- Network helpers ----------

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String {
        return try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val g = wm.dhcpInfo?.gateway ?: 0
            if (g == 0) "" else "${g and 0xff}.${g shr 8 and 0xff}.${g shr 16 and 0xff}.${g shr 24 and 0xff}"
        } catch (e: Exception) {
            ""
        }
    }

    private fun localIps(): String {
        val list = mutableListOf<String>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address) list.add("${ni.name}: ${a.hostAddress}")
                }
            }
        } catch (e: Exception) {
        }
        return if (list.isEmpty()) "No network address yet. Turn on the hotspot first."
        else list.joinToString("\n")
    }

    private fun stopAll() {
        activeSession = 0
        micToken = 0
        micTarget = null
        micLevel = 0
        playLevel = 0
        try { socket?.close() } catch (e: Exception) { }
        socket = null
    }

    private fun post(sid: Int, view: TextView, text: String, color: Int) {
        ui.post {
            if (sid == activeSession) {
                view.text = text
                view.setTextColor(color)
            }
        }
    }

    private val green = Color.parseColor("#4CAF50")
    private val amber = Color.parseColor("#FFB300")
    private val red = Color.parseColor("#F44336")

    private fun levelOf(b: ShortArray): Int {
        var sum = 0.0
        for (v in b) sum += v.toDouble() * v.toDouble()
        val rms = sqrt(sum / b.size)
        if (rms < 1.0) return 0
        val db = 20.0 * log10(rms / 32768.0)
        return (((db + 60.0) / 60.0) * 100.0).toInt().coerceIn(0, 100)
    }

    // ---------- Receiver ----------

    private fun startReceiver(status: TextView) {
        val sid = ++sessionCounter
        activeSession = sid
        status.text = "Starting…"
        status.setTextColor(amber)

        // Make sure any previous playback engine has fully finished first.
        try { playThread?.join(400) } catch (e: InterruptedException) { }
        queue.clear()
        recvPk = 0; lostPk = 0; lateDup = 0; overflow = 0; underruns = 0
        playNote = ""
        haveStream = false

        val pt = Thread { playbackLoop(sid) }
        playThread = pt
        pt.start()

        Thread {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(PORT))
                s.soTimeout = 500
                socket = s
                post(sid, status, "Waiting for the microphone phone…", amber)
                val buf = ByteArray(2048)
                var connected = false
                var lastSeen = 0L
                while (activeSession == sid) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        if (p.length > 0 && buf[0] == AUDIO_TAG) {
                            handleAudio(p)
                            lastSeen = SystemClock.elapsedRealtime()
                            if (!connected) {
                                connected = true
                                post(sid, status, "Connected to ${p.address.hostAddress}", green)
                            }
                        } else {
                            val msg = String(p.data, 0, p.length)
                            if (msg.startsWith(HELLO)) {
                                val reply = (ACK + msg.removePrefix(HELLO)).toByteArray()
                                s.send(DatagramPacket(reply, reply.size, p.address, p.port))
                                lastSeen = SystemClock.elapsedRealtime()
                                if (!connected) {
                                    connected = true
                                    post(sid, status, "Connected to ${p.address.hostAddress}", green)
                                }
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                    if (connected && SystemClock.elapsedRealtime() - lastSeen > 3000) {
                        connected = false
                        post(sid, status, "Microphone phone disconnected. Waiting…", amber)
                    }
                }
            } catch (e: Exception) {
                if (activeSession == sid) {
                    post(sid, status,
                        "Receiver could not start: ${e.message}. Close the app fully and try again.", red)
                }
            } finally {
                try { s?.close() } catch (e: Exception) { }
            }
        }.start()
    }

    // Runs on the receive thread only.
    private fun handleAudio(p: DatagramPacket) {
        if (p.length != HEADER + FRAME_BYTES) return
        val bb = ByteBuffer.wrap(p.data, 0, p.length).order(ByteOrder.LITTLE_ENDIAN)
        bb.get()
        val stream = bb.int
        val seq = bb.int
        if (!haveStream || stream != curStream) {
            haveStream = true
            curStream = stream
            lastSeq = seq - 1
            queue.clear()
        }
        val d = seq - lastSeq
        if (d <= 0) {
            // Duplicate or late packet: never play it twice.
            lateDup++
            return
        }
        if (d > 1) lostPk += d - 1
        lastSeq = seq
        recvPk++
        val payload = ByteArray(FRAME_BYTES)
        System.arraycopy(p.data, HEADER, payload, 0, FRAME_BYTES)
        queue.offer(payload)
        while (queue.size > MAX_QUEUE) {
            queue.poll()
            overflow++
        }
    }

    // The ONE playback engine. Exactly one of these runs per receiver session.
    private fun playbackLoop(sid: Int) {
        var track: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufSize = maxOf(minBuf, FRAME_BYTES * 4)
            val builder = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(bufSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (Build.VERSION.SDK_INT >= 26) {
                builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            }
            track = builder.build()
            track.play()

            val silence = ShortArray(FRAME_SAMPLES)
            val pcm = ShortArray(FRAME_SAMPLES)
            var playing = false
            while (activeSession == sid) {
                var frame: ByteArray? = null
                if (playing) {
                    frame = queue.poll(40, TimeUnit.MILLISECONDS)
                    if (frame == null) {
                        playing = false
                        underruns++
                    }
                } else if (queue.size >= PREFILL) {
                    playing = true
                }
                val n: Int
                if (frame != null) {
                    ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN)
                        .asShortBuffer().get(pcm)
                    playLevel = levelOf(pcm)
                    n = track.write(pcm, 0, FRAME_SAMPLES)
                } else {
                    // Nothing to play: output silence. Old audio is never replayed.
                    playLevel = 0
                    n = track.write(silence, 0, FRAME_SAMPLES)
                }
                if (n < 0) throw IOException("Audio output error ($n)")
            }
        } catch (e: Exception) {
            if (activeSession == sid) {
                playNote = "Audio playback problem: ${e.message}"
            }
        } finally {
            playLevel = 0
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
        }
    }

    // ---------- Microphone ----------

    private fun startMic(ip: String, status: TextView) {
        val sid = ++sessionCounter
        activeSession = sid
        status.text = "Connecting to $ip…"
        status.setTextColor(amber)
        Thread {
            var s: DatagramSocket? = null
            try {
                val target = InetAddress.getByName(ip)
                s = DatagramSocket()
                s.soTimeout = 300
                socket = s
                micTarget = target
                val buf = ByteArray(256)
                val startT = SystemClock.elapsedRealtime()
                var lastAck = 0L
                var lastSend = 0L
                var state = 0 // 0 connecting, 1 connected, 2 lost/no reply
                while (activeSession == sid) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSend >= 1000) {
                        lastSend = now
                        try {
                            val data = (HELLO + System.nanoTime()).toByteArray()
                            s.send(DatagramPacket(data, data.size, target, PORT))
                        } catch (e: IOException) {
                            if (activeSession == sid) {
                                post(sid, status,
                                    "Cannot reach the network. Is this phone joined to the receiver's hotspot?", red)
                            }
                        }
                    }
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val msg = String(p.data, 0, p.length)
                        if (msg.startsWith(ACK)) {
                            val sent = msg.removePrefix(ACK).toLongOrNull()
                            if (sent != null) {
                                val rtt = (System.nanoTime() - sent) / 1_000_000.0
                                lastAck = SystemClock.elapsedRealtime()
                                state = 1
                                post(sid, status,
                                    "Connected to $ip\nRound trip: ${"%.1f".format(rtt)} ms", green)
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                    val t = SystemClock.elapsedRealtime()
                    if (state == 1 && t - lastAck > 3000) {
                        state = 2
                        post(sid, status, "Connection lost. Still trying…", amber)
                    } else if (state == 0 && t - startT > 4000) {
                        state = 2
                        post(sid, status,
                            "No reply from $ip. Check: receiver is started, this phone is on its hotspot, address is correct.", red)
                    }
                }
            } catch (e: Exception) {
                if (activeSession == sid) {
                    post(sid, status, "Could not connect: ${e.message}", red)
                }
            } finally {
                try { s?.close() } catch (e: Exception) { }
            }
        }.start()
    }

    // Starts microphone capture and sends each 20 ms frame as one packet.
    private fun startCapture(sid: Int) {
        val target = micTarget ?: return
        val token = ++micCounter
        micToken = token
        micNote = "Starting microphone…"
        sentPk = 0
        try { micThread?.join(400) } catch (e: InterruptedException) { }
        val t = Thread {
            var rec: AudioRecord? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(
                    RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuf <= 0) throw IOException("This phone does not support the audio format")
                rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, FRAME_BYTES * 4))
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    throw IOException("Microphone could not be opened. Is another app using it?")
                }
                rec.startRecording()
                micNote = "Transmitting"
                val streamId = Random().nextInt()
                var seq = 0
                val shorts = ShortArray(FRAME_SAMPLES)
                while (activeSession == sid && micToken == token) {
                    var got = 0
                    while (got < FRAME_SAMPLES) {
                        val n = rec.read(shorts, got, FRAME_SAMPLES - got)
                        if (n <= 0) throw IOException("Microphone read failed ($n)")
                        got += n
                        if (micToken != token) break
                    }
                    if (got < FRAME_SAMPLES) break
                    micLevel = levelOf(shorts)
                    val bb = ByteBuffer.allocate(HEADER + FRAME_BYTES).order(ByteOrder.LITTLE_ENDIAN)
                    bb.put(AUDIO_TAG)
                    bb.putInt(streamId)
                    bb.putInt(seq)
                    for (v in shorts) bb.putShort(v)
                    val sock = socket ?: break
                    try {
                        sock.send(DatagramPacket(bb.array(), bb.capacity(), target, PORT))
                        sentPk++
                    } catch (e: IOException) {
                        micNote = "Cannot send audio. Is this phone still on the receiver's hotspot?"
                    }
                    seq++
                }
            } catch (e: Exception) {
                micNote = "Microphone problem: ${e.message}"
            } finally {
                micLevel = 0
                try { rec?.stop() } catch (e: Exception) { }
                try { rec?.release() } catch (e: Exception) { }
                if (micToken == token) micToken = 0
            }
        }
        micThread = t
        t.start()
    }
}
