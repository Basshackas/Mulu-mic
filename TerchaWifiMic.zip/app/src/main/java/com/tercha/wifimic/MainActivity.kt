package com.tercha.wifimic

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.util.Collections

class MainActivity : Activity() {

    companion object {
        const val PORT = 5005
        const val HELLO = "TWM-HELLO:"
        const val ACK = "TWM-ACK:"
    }

    private val ui = Handler(Looper.getMainLooper())
    private var onHome = true
    private var sessionCounter = 0

    @Volatile private var activeSession = 0
    @Volatile private var socket: DatagramSocket? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (onHome) super.onBackPressed() else showHome()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(48), dp(24), dp(24))
    }

    private fun label(t: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }

    private fun button(t: String) = Button(this).apply { text = t }

    private fun show(content: View) {
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#101418"))
            addView(content)
        })
    }

    // ---------- Screens ----------

    private fun showHome() {
        stopAll()
        onHome = true
        val root = column().apply { gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(label("Tercha WiFi Mic", 28f, true))
        root.addView(label("Choose this phone's role", 16f, color = Color.LTGRAY))
        val mic = button("MICROPHONE")
        val rec = button("RECEIVER")
        mic.setOnClickListener { showMic() }
        rec.setOnClickListener { showReceiver() }
        root.addView(mic)
        root.addView(rec)
        show(root)
    }

    private fun showReceiver() {
        stopAll()
        onHome = false
        val root = column()
        root.addView(label("RECEIVER", 22f, true))
        root.addView(label(
            "1. Turn on this phone's Hotspot (Settings).\n" +
            "2. Tap Start receiver.\n" +
            "3. On the microphone phone, join this hotspot.",
            14f, color = Color.LTGRAY))
        val status = label("Stopped", 18f, true, Color.parseColor("#FFB300"))
        val ips = label(localIps(), 14f, color = Color.LTGRAY)
        val btn = button("Start receiver")
        btn.setOnClickListener {
            if (activeSession != 0) {
                stopAll()
                status.text = "Stopped"
                btn.text = "Start receiver"
            } else {
                ips.text = localIps()
                startReceiver(status)
                btn.text = "Stop receiver"
            }
        }
        root.addView(btn)
        root.addView(status)
        root.addView(label("This phone's address(es):", 14f, true))
        root.addView(ips)
        show(root)
    }

    private fun showMic() {
        stopAll()
        onHome = false
        val root = column()
        root.addView(label("MICROPHONE", 22f, true))
        root.addView(label(
            "1. Join the receiver phone's hotspot in Wi-Fi settings.\n" +
            "2. Check the receiver's address below.\n" +
            "3. Tap Connect.",
            14f, color = Color.LTGRAY))
        val ip = EditText(this).apply {
            setText(gatewayIp())
            hint = "Receiver address, e.g. 192.168.43.1"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_PHONE
        }
        val status = label("Not connected", 18f, true, Color.parseColor("#FFB300"))
        val btn = button("Connect")
        btn.setOnClickListener {
            if (activeSession != 0) {
                stopAll()
                status.text = "Not connected"
                btn.text = "Connect"
            } else {
                val addr = ip.text.toString().trim()
                if (!Regex("""\d{1,3}(\.\d{1,3}){3}""").matches(addr)) {
                    status.text = "Enter the receiver's address as four numbers, like 192.168.43.1"
                } else {
                    startMic(addr, status)
                    btn.text = "Disconnect"
                }
            }
        }
        root.addView(ip)
        root.addView(btn)
        root.addView(status)
        show(root)
    }

    // ---------- Network helpers ----------

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String {
        return try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val g = wm.dhcpInfo?.gateway ?: 0
            if (g == 0) "" else "${g and 0xff}.${g shr 8 and 0xff}.${g shr 16 and 0xff}.${g shr 24 and 0xff}"
        } catch (e: Exception) {
            ""
        }
    }

    private fun localIps(): String {
        val list = mutableListOf<String>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address) list.add("${ni.name}: ${a.hostAddress}")
                }
            }
        } catch (e: Exception) {
        }
        return if (list.isEmpty()) "No network address yet. Turn on the hotspot first."
        else list.joinToString("\n")
    }

    private fun stopAll() {
        activeSession = 0
        try { socket?.close() } catch (e: Exception) { }
        socket = null
    }

    private fun post(sid: Int, view: TextView, text: String, color: Int) {
        ui.post {
            if (sid == activeSession) {
                view.text = text
                view.setTextColor(color)
            }
        }
    }

    private val green = Color.parseColor("#4CAF50")
    private val amber = Color.parseColor("#FFB300")
    private val red = Color.parseColor("#F44336")

    // ---------- Receiver ----------

    private fun startReceiver(status: TextView) {
        val sid = ++sessionCounter
        activeSession = sid
        status.text = "Starting…"
        Thread {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(PORT))
                s.soTimeout = 500
                socket = s
                post(sid, status, "Waiting for the microphone phone…", amber)
                val buf = ByteArray(256)
                var connected = false
                var lastSeen = 0L
                while (activeSession == sid) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val msg = String(p.data, 0, p.length)
                        if (msg.startsWith(HELLO)) {
                            val reply = (ACK + msg.removePrefix(HELLO)).toByteArray()
                            s.send(DatagramPacket(reply, reply.size, p.address, p.port))
                            lastSeen = SystemClock.elapsedRealtime()
                            if (!connected) {
                                connected = true
                                post(sid, status, "Connected to ${p.address.hostAddress}", green)
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                    if (connected && SystemClock.elapsedRealtime() - lastSeen > 3000) {
                        connected = false
                        post(sid, status, "Microphone phone disconnected. Waiting…", amber)
                    }
                }
            } catch (e: Exception) {
                if (activeSession == sid) {
                    post(sid, status,
                        "Receiver could not start: ${e.message}. Close the app fully and try again.", red)
                }
            } finally {
                try { s?.close() } catch (e: Exception) { }
            }
        }.start()
    }

    // ---------- Microphone ----------

    private fun startMic(ip: String, status: TextView) {
        val sid = ++sessionCounter
        activeSession = sid
        status.text = "Connecting to $ip…"
        status.setTextColor(amber)
        Thread {
            var s: DatagramSocket? = null
            try {
                val target = InetAddress.getByName(ip)
                s = DatagramSocket()
                s.soTimeout = 300
                socket = s
                val buf = ByteArray(256)
                val startT = SystemClock.elapsedRealtime()
                var lastAck = 0L
                var lastSend = 0L
                var state = 0 // 0 connecting, 1 connected, 2 lost/no reply
                while (activeSession == sid) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSend >= 1000) {
                        lastSend = now
                        try {
                            val data = (HELLO + System.nanoTime()).toByteArray()
                            s.send(DatagramPacket(data, data.size, target, PORT))
                        } catch (e: IOException) {
                            if (activeSession == sid) {
                                post(sid, status,
                                    "Cannot reach the network. Is this phone joined to the receiver's hotspot?", red)
                            }
                        }
                    }
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val msg = String(p.data, 0, p.length)
                        if (msg.startsWith(ACK)) {
                            val sent = msg.removePrefix(ACK).toLongOrNull()
                            if (sent != null) {
                                val rtt = (System.nanoTime() - sent) / 1_000_000.0
                                lastAck = SystemClock.elapsedRealtime()
                                state = 1
                                post(sid, status,
                                    "Connected to $ip\nRound trip: ${"%.1f".format(rtt)} ms", green)
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                    val t = SystemClock.elapsedRealtime()
                    if (state == 1 && t - lastAck > 3000) {
                        state = 2
                        post(sid, status, "Connection lost. Still trying…", amber)
                    } else if (state == 0 && t - startT > 4000) {
                        state = 2
                        post(sid, status,
                            "No reply from $ip. Check: receiver is started, this phone is on its hotspot, address is correct.", red)
                    }
                }
            } catch (e: Exception) {
                if (activeSession == sid) {
                    post(sid, status, "Could not connect: ${e.message}", red)
                }
            } finally {
                try { s?.close() } catch (e: Exception) { }
            }
        }.start()
    }
}
