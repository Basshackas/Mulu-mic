package com.tercha.wifimic

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.media.*
import android.net.wifi.p2p.*
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.widget.*
import java.net.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.sqrt

class MainActivity : Activity() {
    private val port = 39393
    private val rate = 48000
    private val samples = 480
    private val payload = samples * 2
    private lateinit var p2p: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var status: TextView
    private lateinit var peers: LinearLayout
    private lateinit var meter: ProgressBar
    private lateinit var outputSpinner: Spinner
    private var outputDevices: List<AudioDeviceInfo> = emptyList()
    @Volatile private var selectedOutputId: Int = -1
    @Volatile private var role = "none"
    @Volatile private var connected = false
    @Volatile private var ownerAddress: InetAddress? = null
    @Volatile private var receiverRunning = false
    private val sending = AtomicBoolean(false)
    @Volatile private var rec: AudioRecord? = null
    @Volatile private var tx: DatagramSocket? = null
    @Volatile private var rx: DatagramSocket? = null
    @Volatile private var track: AudioTrack? = null
    private var receiver: BroadcastReceiver? = null
    private var sequence = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var groupRequestInFlight = false
    private var groupRetryCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p2p = getSystemService(WIFI_P2P_SERVICE) as WifiP2pManager
        channel = p2p.initialize(this, mainLooper, null)
        ui()
        registerP2p()
        permissions()
    }

    private fun ui() {
        val root = LinearLayout(this).apply { orientation=1; setPadding(22,26,22,20) }
        root.addView(TextView(this).apply { text="Tercha WiFi Mic"; textSize=28f; gravity=Gravity.CENTER })
        root.addView(TextView(this).apply { text="Mission 2 • Phone-to-phone live audio"; gravity=Gravity.CENTER; setPadding(0,8,0,18) })
        root.addView(Button(this).apply {
            text="PHONE B — Create receiver group"
            setOnClickListener { role="receiver"; groupRetryCount=0; createGroupSafely() }
        })
        root.addView(Button(this).apply {
            text="RESET RECEIVER GROUP (disconnects current group)"
            setOnClickListener { role="receiver"; resetReceiverGroup() }
        })
        root.addView(Button(this).apply {
            text="PHONE A — Discover receiver"
            setOnClickListener { role="mic"; discover() }
        })
        root.addView(TextView(this).apply { text="Found phones (tap Phone B):"; setPadding(0,12,0,4) })
        peers=LinearLayout(this).apply { orientation=1 }; root.addView(peers)
        status=TextView(this).apply { text="Start on Phone B first."; textSize=15f; setPadding(0,14,0,12) }
        root.addView(status)
        root.addView(Button(this).apply { text="Start microphone (Phone A)"; setOnClickListener { startMic() } })
        root.addView(Button(this).apply { text="Stop microphone"; setOnClickListener { stopMic() } })
        root.addView(TextView(this).apply { text="Microphone level"; setPadding(0,12,0,4) })
        meter=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100 }
        root.addView(meter,LinearLayout.LayoutParams(-1,20))
        root.addView(TextView(this).apply { text="Receiver audio output"; setPadding(0,16,0,4) })
        outputSpinner = Spinner(this)
        root.addView(outputSpinner)
        root.addView(Button(this).apply { text="Refresh audio outputs"; setOnClickListener { refreshOutputs() } })
        refreshOutputs()
        root.addView(TextView(this).apply {
            text="Phone B sends audio to its active Android media output. Connect the RDS mixer by Bluetooth or a compatible wired/USB audio adapter. Wired is preferred for lower delay. Start with speakers muted."
            setPadding(0,18,0,0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun permissions() {
        val wanted=mutableListOf<String>()
        if(Build.VERSION.SDK_INT>=33) wanted.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        else wanted.add(Manifest.permission.ACCESS_FINE_LOCATION)
        wanted.add(Manifest.permission.RECORD_AUDIO)
        val missing=wanted.distinct().filter { checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED }
        if(missing.isNotEmpty()) requestPermissions(missing.toTypedArray(),8)
    }

    private fun registerP2p() {
        val f=IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        receiver=object:BroadcastReceiver() {
            override fun onReceive(c:Context?,i:Intent?) {
                when(i?.action) {
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> listPeers()
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> connectionInfo()
                }
            }
        }
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED) else registerReceiver(receiver,f)
    }

    // Phone B is the group owner. Avoid overlapping requests, inspect existing
    // group state first, and retry BUSY responses instead of spamming createGroup().
    private fun createGroupSafely() {
        if (groupRequestInFlight) {
            status.text = "Wi-Fi Direct is already processing a request. Please wait."
            return
        }
        groupRequestInFlight = true
        status.text = "Checking existing Wi-Fi Direct group…"
        try {
            p2p.requestGroupInfo(channel) { group ->
                if (group != null) {
                    groupRequestInFlight = false
                    p2p.requestConnectionInfo(channel) { info ->
                        if (info.groupFormed && info.isGroupOwner) {
                            connected = true
                            role = "receiver"
                            status.text = "Receiver group is already active. Now discover from Phone A."
                            startReceiver()
                        } else {
                            status.text = "A Wi-Fi Direct group already exists. Use RESET only if you want to disconnect it."
                        }
                    }
                } else {
                    issueCreateGroup()
                }
            }
        } catch (e: SecurityException) {
            groupRequestInFlight = false
            status.text = "Wi-Fi Direct permission missing: ${e.message}"
        } catch (e: Exception) {
            groupRequestInFlight = false
            status.text = "Could not inspect Wi-Fi Direct state: ${e.message}"
        }
    }

    private fun issueCreateGroup() {
        status.text = "Phone B: requesting receiver group…"
        try {
            p2p.createGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    groupRequestInFlight = false
                    groupRetryCount = 0
                    status.text = "Phone B group created. Now discover from Phone A."
                    mainHandler.postDelayed({ connectionInfo() }, 700)
                }
                override fun onFailure(reason: Int) {
                    if (reason == WifiP2pManager.BUSY && groupRetryCount < 3) {
                        groupRetryCount++
                        status.text = "Wi-Fi Direct busy. Checking group state; retry ${groupRetryCount}/3…"
                        mainHandler.postDelayed({
                            groupRequestInFlight = false
                            createGroupSafely()
                        }, 1800L * groupRetryCount)
                    } else {
                        groupRequestInFlight = false
                        val detail = when (reason) {
                            WifiP2pManager.BUSY -> "Android Wi-Fi Direct remains busy after retries. Try RESET RECEIVER GROUP."
                            WifiP2pManager.ERROR -> "Android reported an internal Wi-Fi Direct error."
                            WifiP2pManager.P2P_UNSUPPORTED -> "This phone reports that Wi-Fi Direct is unsupported."
                            else -> "Android rejected the request. Check Wi-Fi and permissions."
                        }
                        status.text = "Create group failed ($reason): $detail"
                    }
                }
            })
        } catch (e: SecurityException) {
            groupRequestInFlight = false
            status.text = "Wi-Fi Direct permission missing: ${e.message}"
        } catch (e: Exception) {
            groupRequestInFlight = false
            status.text = "Create group request error: ${e.message}"
        }
    }

    // Explicit user action only: removes the current P2P group, then requests a fresh one.
    private fun resetReceiverGroup() {
        if (groupRequestInFlight) {
            status.text = "Please wait for the current Wi-Fi Direct request to finish."
            return
        }
        groupRequestInFlight = true
        status.text = "Resetting receiver group…"
        try {
            p2p.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    connected = false
                    stopReceiver()
                    ownerAddress = null
                    groupRequestInFlight = false
                    groupRetryCount = 0
                    status.text = "Old group removed. Creating a fresh receiver group…"
                    mainHandler.postDelayed({ createGroupSafely() }, 1200)
                }
                override fun onFailure(reason: Int) {
                    groupRequestInFlight = false
                    if (reason == WifiP2pManager.BUSY) {
                        status.text = "Android is busy resetting the group. Wait a few seconds and try RESET again."
                    } else {
                        status.text = "Group reset failed ($reason). No existing group may need removal; try Create receiver group."
                    }
                }
            })
        } catch (e: Exception) {
            groupRequestInFlight = false
            status.text = "Group reset error: ${e.message}"
        }
    }

    private fun discover() {
        peers.removeAllViews()
        status.text="Phone A: searching for Phone B…"
        p2p.discoverPeers(channel,object:WifiP2pManager.ActionListener {
            override fun onSuccess(){status.text="Searching…"}
            override fun onFailure(r:Int){status.text="Discovery failed ($r). Check Wi-Fi permissions."}
        })
    }

    private fun listPeers() {
        p2p.requestPeers(channel) { list ->
            runOnUiThread {
                peers.removeAllViews()
                list.deviceList.forEach { d ->
                    peers.addView(Button(this).apply {
                        text=d.deviceName
                        setOnClickListener {
                            val cfg=WifiP2pConfig().apply { deviceAddress=d.deviceAddress }
                            p2p.connect(channel,cfg,object:WifiP2pManager.ActionListener {
                                override fun onSuccess(){status.text="Connecting to ${d.deviceName}…"}
                                override fun onFailure(r:Int){status.text="Connection failed ($r). Retry."}
                            })
                        }
                    })
                }
                if(list.deviceList.isEmpty() && role=="mic") status.text="No receiver found. Create group on Phone B first."
            }
        }
    }

    private fun connectionInfo() {
        p2p.requestConnectionInfo(channel) { info ->
            connected=info.groupFormed
            ownerAddress=info.groupOwnerAddress
            if(connected && info.isGroupOwner) {
                role="receiver"
                status.text="Phone B connected. Waiting for microphone audio."
                startReceiver()
            } else if(connected) {
                role="mic"
                status.text="Phone A connected. Tap Start microphone."
            } else {
                status.text="Wi-Fi Direct disconnected."
                stopReceiver()
            }
        }
    }


    private fun refreshOutputs() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        outputDevices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val labels = mutableListOf("System default")
        outputDevices.forEach { d ->
            val kind = when (d.type) {
                AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Phone speaker"
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headset"
                AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB audio"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Bluetooth"
                else -> "Audio device"
            }
            labels.add("$kind — ${d.productName}")
        }
        outputSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        outputSpinner.setSelection(0)
        outputSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedOutputId = if (position == 0) -1 else outputDevices.getOrNull(position - 1)?.id ?: -1
                track?.let { applySelectedOutput(it) }
            }
        }
    }

    private fun applySelectedOutput(audio: AudioTrack) {
        // Do not pass a null/default device to setPreferredDevice(). Some Android
        // vendor audio HALs reject the null device with "port out of range: -1".
        // Leaving the preferred device unset lets Android use its normal routing.
        val id = selectedOutputId
        if (id < 0) return
        val device = outputDevices.firstOrNull { it.id == id } ?: return
        try {
            audio.setPreferredDevice(device)
        } catch (e: IllegalArgumentException) {
            runOnUiThread { status.text = "Audio route unavailable; using system default." }
        } catch (e: IllegalStateException) {
            runOnUiThread { status.text = "Audio route unavailable; using system default." }
        }
    }

    private fun startReceiver() {
        if(receiverRunning) return
        receiverRunning=true
        thread(name="audio-rx") {
            var socket:DatagramSocket?=null
            var audio:AudioTrack?=null
            var stage="start"
            try {
                stage="check port"
                require(port in 1..65535) { "Invalid audio network port: $port" }
                stage="open UDP socket"
                socket=DatagramSocket(null).apply { reuseAddress=true; bind(InetSocketAddress(port)); soTimeout=1000 }
                stage="create AudioTrack"
                rx=socket
                val min=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)
                audio=AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(maxOf(min,payload*6))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()
                track=audio
                stage="apply audio route"
                applySelectedOutput(audio)
                stage="start playback"
                audio.play()
                stage="receive loop"
                val data=ByteArray(4+payload)
                while(receiverRunning && connected && !socket.isClosed) {
                    try {
                        val packet=DatagramPacket(data,data.size)
                        socket.receive(packet)
                        if(packet.length!=data.size) continue
                        val shorts=ShortArray(samples)
                        ByteBuffer.wrap(packet.data,4,payload).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
                        audio.write(shorts,0,shorts.size,AudioTrack.WRITE_BLOCKING)
                    } catch(_:SocketTimeoutException) {}
                }
            } catch(e:Exception) {
                Log.e("TerchaWiFiMic","Receiver failed at stage '$stage'",e)
                runOnUiThread { status.text="Receiver error at [$stage]: ${e.javaClass.simpleName}: ${e.message}" }
            } finally {
                try{audio?.stop()}catch(_:Exception){}
                try{audio?.release()}catch(_:Exception){}
                try{socket?.close()}catch(_:Exception){}
                track=null; rx=null; receiverRunning=false
            }
        }
    }

    private fun startMic() {
        if(role!="mic" || !connected || ownerAddress==null) {
            status.text="First create the group on Phone B, then connect Phone A."; return
        }
        if(sending.get()) return
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),8); return
        }
        sending.set(true)
        thread(name="audio-tx") {
            var audio:AudioRecord?=null
            var socket:DatagramSocket?=null
            try {
                val min=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
                audio=AudioRecord(MediaRecorder.AudioSource.MIC,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,maxOf(min,payload*6))
                check(audio.state==AudioRecord.STATE_INITIALIZED) { "Microphone initialization failed" }
                socket=DatagramSocket()
                rec=audio; tx=socket
                val dest=ownerAddress ?: error("Receiver address unavailable")
                val pcm=ShortArray(samples)
                val packet=ByteArray(4+payload)
                sequence=0
                audio.startRecording()
                runOnUiThread { status.text="Phone A transmitting live audio." }
                while(sending.get() && connected) {
                    val n=audio.read(pcm,0,samples,AudioRecord.READ_BLOCKING)
                    if(n<=0) continue
                    var sum=0.0
                    for(i in 0 until samples) {
                        val v=if(i<n) pcm[i].toInt() else 0
                        sum+=v.toDouble()*v
                        packet[4+i*2]=(v and 255).toByte()
                        packet[5+i*2]=((v shr 8) and 255).toByte()
                    }
                    ByteBuffer.wrap(packet,0,4).order(ByteOrder.BIG_ENDIAN).putInt(sequence++)
                    socket.send(DatagramPacket(packet,packet.size,dest,port))
                    val rms=sqrt(sum/samples)
                    runOnUiThread { meter.progress=((rms/32768.0)*100).toInt().coerceIn(0,100) }
                }
            } catch(e:Exception) {
                runOnUiThread { status.text="Mic error: ${e.message}" }
            } finally {
                try{audio?.stop()}catch(_:Exception){}
                try{audio?.release()}catch(_:Exception){}
                try{socket?.close()}catch(_:Exception){}
                rec=null; tx=null; sending.set(false)
                runOnUiThread { meter.progress=0 }
            }
        }
    }

    private fun stopMic() {
        sending.set(false)
        try{rec?.stop()}catch(_:Exception){}
        try{tx?.close()}catch(_:Exception){}
        meter.progress=0
        if(role=="mic") status.text="Microphone stopped."
    }

    private fun stopReceiver() {
        receiverRunning=false
        try{rx?.close()}catch(_:Exception){}
        try{track?.pause()}catch(_:Exception){}
        try{track?.flush()}catch(_:Exception){}
        try{track?.stop()}catch(_:Exception){}
        try{track?.release()}catch(_:Exception){}
        rx=null; track=null
    }

    override fun onDestroy() {
        stopMic(); stopReceiver()
        connected=false
        try{unregisterReceiver(receiver)}catch(_:Exception){}
        super.onDestroy()
    }
}

